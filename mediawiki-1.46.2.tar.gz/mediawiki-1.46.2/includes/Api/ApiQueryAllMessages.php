<?php
/**
 * Copyright © 2006 Yuri Astrakhan "<Firstname><Lastname>@gmail.com"
 *
 * @license GPL-2.0-or-later
 * @file
 */

namespace MediaWiki\Api;

use MediaWiki\Language\Language;
use MediaWiki\Language\LanguageFactory;
use MediaWiki\Language\LanguageNameUtils;
use MediaWiki\Language\LocalisationCache;
use MediaWiki\Language\MessageCache;
use MediaWiki\Specials\Pager\AllMessagesTablePager;
use MediaWiki\Title\Title;
use Wikimedia\ParamValidator\ParamValidator;

/**
 * A query action to return messages from site message cache
 *
 * @ingroup API
 */
class ApiQueryAllMessages extends ApiQueryBase {

	public function __construct(
		ApiQuery $query,
		string $moduleName,
		private readonly Language $contentLanguage,
		private readonly LanguageFactory $languageFactory,
		private readonly LanguageNameUtils $languageNameUtils,
		private readonly LocalisationCache $localisationCache,
		private readonly MessageCache $messageCache,
	) {
		parent::__construct( $query, $moduleName, 'am' );
	}

	public function execute() {
		$params = $this->extractRequestParams();
		if ( $params['lang'] === null ) {
			$langObj = $this->getLanguage();
		} elseif ( !$this->languageNameUtils->isValidCode( $params['lang'] ) ) {
			$this->dieWithError(
				[ 'apierror-invalidlang', $this->encodeParamName( 'lang' ) ], 'invalidlang'
			);
		} else {
			$langObj = $this->languageFactory->getLanguage( $params['lang'] );
		}

		if ( $params['enableparser'] ) {
			if ( $params['title'] !== null ) {
				$title = Title::newFromText( $params['title'] );
				if ( !$title || $title->isExternal() ) {
					$this->dieWithError( [ 'apierror-invalidtitle', wfEscapeWikiText( $params['title'] ) ] );
				}
			} else {
				$title = Title::newFromText( 'API' );
			}
		}

		$prop = array_fill_keys( (array)$params['prop'], true );

		// Determine which messages should we print
		if ( in_array( '*', $params['messages'] ) ) {
			$message_names = $this->localisationCache->getSubitemList( $langObj->getCode(), 'messages' ) ?? [];
			if ( $params['includelocal'] ) {
				$message_names = array_unique( array_merge(
					$message_names,
					// Pass in the content language code so we get local messages that have a
					// MediaWiki:msgkey page. We might theoretically miss messages that have no
					// MediaWiki:msgkey page but do have a MediaWiki:msgkey/lang page, but that's
					// just a stupid case.
					$this->messageCache->getAllMessageKeys( $this->contentLanguage->getCode() )
				) );
			}
			sort( $message_names );
			$messages_target = $message_names;
		} else {
			$messages_target = $params['messages'];
		}

		// Filter messages that have the specified prefix
		// Because we sorted the message array earlier, they will appear in a clump:
		if ( isset( $params['prefix'] ) ) {
			$skip = false;
			$messages_filtered = [];
			foreach ( $messages_target as $message ) {
				if ( str_starts_with( $message, $params['prefix'] ) ) {
					if ( !$skip ) {
						$skip = true;
					}
					$messages_filtered[] = $message;
				} elseif ( $skip ) {
					break;
				}
			}
			$messages_target = $messages_filtered;
		}

		// Filter messages that contain specified string
		if ( isset( $params['filter'] ) ) {
			$messages_filtered = [];
			foreach ( $messages_target as $message ) {
				if ( str_contains( $message, $params['filter'] ) ) {
					$messages_filtered[] = $message;
				}
			}
			$messages_target = $messages_filtered;
		}

		// Whether we have any sort of message customisation filtering
		$customiseFilterEnabled = $params['customised'] !== 'all';
		if ( $customiseFilterEnabled ) {
			$customisedMessages = AllMessagesTablePager::getCustomisedStatuses(
				array_map(
					$langObj->ucfirst( ... ),
					$messages_target
				),
				$langObj->getCode(),
				!$langObj->equals( $this->contentLanguage ),
				$this->getDB()
			);

			$customised = $params['customised'] === 'modified';
		}

		// Get all requested messages and print the result
		$skip = $params['from'] !== null;
		$useto = $params['to'] !== null;
		$result = $this->getResult();
		foreach ( $messages_target as $message ) {
			// Skip all messages up to $params['from']
			if ( $skip && $message === $params['from'] ) {
				$skip = false;
			}

			if ( $useto && $message > $params['to'] ) {
				break;
			}

			if ( !$skip ) {
				$a = [
					'name' => $message,
					'normalizedname' => $this->messageCache->normalizeKey( $message ),
				];

				$args = [];
				if ( isset( $params['args'] ) && count( $params['args'] ) != 0 ) {
					$args = $params['args'];
				}

				if ( $customiseFilterEnabled ) {
					$messageIsCustomised = isset( $customisedMessages['pages'][$langObj->ucfirst( $message )] );
					// @phan-suppress-next-line PhanPossiblyUndeclaredVariable customised is set when used
					if ( $customised === $messageIsCustomised ) {
						// @phan-suppress-next-line PhanPossiblyUndeclaredVariable customised is set when used
						if ( $customised ) {
							$a['customised'] = true;
						}
					} else {
						continue;
					}
				}

				$msg = $this->msg( $message, $args )->inLanguage( $langObj );

				if ( !$msg->exists() ) {
					$a['missing'] = true;
				} else {
					// Check if the parser is enabled:
					if ( $params['enableparser'] ) {
						// @phan-suppress-next-line PhanPossiblyUndeclaredVariable title is set when used
						$msgString = $msg->page( $title )->text();
					} else {
						$msgString = $msg->plain();
					}
					if ( !$params['nocontent'] ) {
						ApiResult::setContentValue( $a, 'content', $msgString );
					}
					if ( isset( $prop['default'] ) ) {
						$default = $this->msg( $message )->inLanguage( $langObj )->useDatabase( false );
						if ( !$default->exists() ) {
							$a['defaultmissing'] = true;
						} elseif ( $default->plain() != $msgString ) {
							$a['default'] = $default->plain();
						}
					}
				}
				$fit = $result->addValue( [ 'query', $this->getModuleName() ], null, $a );
				if ( !$fit ) {
					$this->setContinueEnumParameter( 'from', $message );
					break;
				}
			}
		}
		$result->addIndexedTagName( [ 'query', $this->getModuleName() ], 'message' );
	}

	/** @inheritDoc */
	public function getCacheMode( $params ) {
		if ( $params['lang'] === null ) {
			// Language not specified, will be fetched from preferences
			return 'anon-public-user-private';
		} elseif ( $params['enableparser'] ) {
			// User-specific parser options will be used
			return 'anon-public-user-private';
		} else {
			// OK to cache
			return 'public';
		}
	}

	/** @inheritDoc */
	public function getAllowedParams() {
		return [
			'messages' => [
				ParamValidator::PARAM_DEFAULT => '*',
				ParamValidator::PARAM_ISMULTI => true,
			],
			'prop' => [
				ParamValidator::PARAM_ISMULTI => true,
				ParamValidator::PARAM_TYPE => [
					'default'
				]
			],
			'enableparser' => false,
			'nocontent' => false,
			'includelocal' => false,
			'args' => [
				ParamValidator::PARAM_ISMULTI => true,
				ParamValidator::PARAM_ALLOW_DUPLICATES => true,
			],
			'filter' => [],
			'customised' => [
				ParamValidator::PARAM_DEFAULT => 'all',
				ParamValidator::PARAM_TYPE => [
					'all',
					'modified',
					'unmodified'
				]
			],
			'lang' => null,
			'from' => null,
			'to' => null,
			'title' => null,
			'prefix' => null,
		];
	}

	/** @inheritDoc */
	protected function getExamplesMessages() {
		return [
			'action=query&meta=allmessages&amprefix=ipb-'
				=> 'apihelp-query+allmessages-example-ipb',
			'action=query&meta=allmessages&ammessages=august|mainpage&amlang=de'
				=> 'apihelp-query+allmessages-example-de',
		];
	}

	/** @inheritDoc */
	public function getHelpUrls() {
		return 'https://www.mediawiki.org/wiki/Special:MyLanguage/API:Allmessages';
	}
}

/** @deprecated class alias since 1.43 */
class_alias( ApiQueryAllMessages::class, 'ApiQueryAllMessages' );
