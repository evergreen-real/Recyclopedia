<?php
/**
 * @license GPL-2.0-or-later
 */

namespace MediaWiki\Composer;

use Composer\Script\Event;
use DOMDocument;
use DOMNode;
use InvalidArgumentException;

/**
 * Edit phpunit.xml to speed up code coverage generation.
 *
 * Usage: composer phpunit:coverage-edit -- extensions/ExtensionName
 *
 * This class runs *outside* of the normal MediaWiki
 * environment and cannot depend upon any MediaWiki
 * code.
 */
class ComposerPhpunitXmlCoverageEdit {
	/**
	 * @param Event $event
	 */
	public static function onEvent( $event ) {
		$IP = dirname( dirname( __DIR__ ) );
		// TODO: Support passing arbitrary directories for core (or extensions/skins).
		$args = $event->getArguments();
		if ( count( $args ) !== 1 ) {
			throw new InvalidArgumentException( 'Pass extensions/$extensionName as an argument, ' .
				'e.g. "composer phpunit:coverage-edit -- extensions/BoilerPlate"' );
		}
		$project = current( $args );
		$phpunitXml = new DomDocument();
		$phpunitXml->load( $IP . '/phpunit.xml' );
		$include = iterator_to_array( $phpunitXml->getElementsByTagName( 'include' ) );
		/** @var DOMNode $childNode */
		foreach ( $include as $childNode ) {
			$childNode->parentNode->removeChild( $childNode );
		}
		$includeElement = $phpunitXml->createElement( 'include' );
		// TODO: Use AutoloadClasses from extension.json to load the relevant directories
		foreach ( [ 'includes', 'src', 'maintenance' ] as $dir ) {
			$dirElement = $phpunitXml->createElement( 'directory', $project . '/' . $dir );
			$dirElement->setAttribute( 'suffix', '.php' );
			$includeElement->appendChild( $dirElement );

		}
		$phpunitXml->getElementsByTagName( 'coverage' )->item( 0 )
			->appendChild( $includeElement );
		$phpunitXml->formatOutput = true;
		$phpunitXml->save( $IP . '/phpunit.xml' );
	}
}
