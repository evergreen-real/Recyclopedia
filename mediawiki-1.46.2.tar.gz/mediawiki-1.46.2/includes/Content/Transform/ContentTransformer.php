<?php
namespace MediaWiki\Content\Transform;

use MediaWiki\Content\Content;
use MediaWiki\Content\IContentHandlerFactory;
use MediaWiki\Page\PageReference;
use MediaWiki\Parser\ParserOptions;
use MediaWiki\User\UserIdentity;

/**
 * A service to transform content.
 *
 * @since 1.37
 */
class ContentTransformer {
	public function __construct(
		private readonly IContentHandlerFactory $contentHandlerFactory,
	) {
	}

	/**
	 * Returns a Content object with pre-save transformations applied (or $content
	 * if no transformations apply).
	 */
	public function preSaveTransform(
		Content $content,
		PageReference $page,
		UserIdentity $user,
		ParserOptions $parserOptions
	): Content {
		$contentHandler = $this->contentHandlerFactory->getContentHandler( $content->getModel() );
		$pstParams = new PreSaveTransformParamsValue( $page, $user, $parserOptions );

		return $contentHandler->preSaveTransform( $content, $pstParams );
	}

	/**
	 * Returns a Content object with preload transformations applied (or $content
	 * if no transformations apply).
	 */
	public function preloadTransform(
		Content $content,
		PageReference $page,
		ParserOptions $parserOptions,
		array $params = []
	): Content {
		$contentHandler = $this->contentHandlerFactory->getContentHandler( $content->getModel() );
		$pltParams = new PreloadTransformParamsValue( $page, $parserOptions, $params );

		return $contentHandler->preloadTransform( $content, $pltParams );
	}
}
